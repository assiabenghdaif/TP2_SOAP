package fsm.miaad.springclient.controllers;

import fsm.miaad.springclient.models.Compte;
import org.springframework.stereotype.Component;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.Date;
import java.util.Vector;

@Component
@WebService
public class CompteController {

    @WebMethod
    public double convert(@WebParam(name="amount")double amount){
        return amount*11.23;
    }

    @WebMethod
    public Compte getCompte(@WebParam(name="code")int code){
        return new Compte(code,Math.random()*2001,new Date());
    }

    @WebMethod
    public Vector<Compte> allComptes(){
        Vector<Compte> comptes=new Vector<>();

        comptes.add(new Compte(1, Math.random()*2001, new Date()));
        comptes.add(new Compte(2, Math.random()*2001, new Date()));
        comptes.add(new Compte(3, Math.random()*2001, new Date()));
        return comptes;

    }
}
