package fsm.miaad.springclient;

//import com.example.springclient.reposistories.CompteRepo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringClientApplication.class, args);
        System.out.println("  .   ____          _            __ _ _\n" +
                " /\\\\ / ___'_ __ _ _(_)_ __  __ _ \\ \\ \\ \\\n" +
                "( ( )\\___ | '_ | '_| | '_ \\/ _` | \\ \\ \\ \\\n" +
                " \\\\/  ___)| |_)| | | | | || (_| |  ) ) ) )\n" +
                "  '  |____| .__|_| |_|_| |_\\__, | / / / /\n" +
                " =========|_|==============|___/=/_/_/_/");
    }

//    @Bean
//    CommandLineRunner start(CompteRepo compteRepo){
//        return args->{
//            compteRepo.save(new Compte(null,Math.random()*2001,new Date()));
//
//            compteRepo.findAll().forEach(compte->{
//                System.out.println(compte.toString());
//            });
//        };
//    }

}
