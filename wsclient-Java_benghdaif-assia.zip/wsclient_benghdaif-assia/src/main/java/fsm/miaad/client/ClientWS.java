package fsm.miaad.client;

import fsm.miaad.proxy.BankWS;
import fsm.miaad.proxy.BanqueService;
import fsm.miaad.proxy.Compte;

public class ClientWS {

    public static void main(String[] args) {
        BanqueService stub=new BankWS().getBanqueServicePort();

        double amount=300;
        System.out.println(amount+" euro = "+stub.convert(amount)+" DHs");

        Compte compte=stub.getCompte(5);
        System.out.println("code => "+compte.getCode()+"\n solde => "+compte.getSolde());


    }
}
