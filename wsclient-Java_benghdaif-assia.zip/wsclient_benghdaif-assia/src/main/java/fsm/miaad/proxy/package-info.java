@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://ws.miaad.fsm/")
package fsm.miaad.proxy;
