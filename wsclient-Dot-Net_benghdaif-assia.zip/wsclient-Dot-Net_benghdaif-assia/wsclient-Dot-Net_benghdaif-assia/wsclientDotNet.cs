﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wsclient_Dot_Net_benghdaif_assia
{
    internal class wsclientDotNet
    {
        static void Main(string[] args)
        {
            BankServises.BanqueServiceClient stub = new BankServises.BanqueServiceClient();

            Console.WriteLine("==========================================\n*Convert");
            var amount=300;
            Console.WriteLine("\t" + amount+" Euro est " +stub.Convert(amount)+" DHs");

            Console.WriteLine("==========================================");

            BankServises.compte compte = stub.getCompte(6);
            Console.WriteLine("*get Compte\n\tle code => " + compte.code + " le solde => " + compte.solde);

            Console.WriteLine("==========================================\n*All Comptes");

            BankServises.compte[] comptes = stub.allComptes();

            foreach(var cmpte in comptes)
            {
                Console.WriteLine("==========================================");
                Console.WriteLine("\tle code => " + cmpte.code + " le solde => " + cmpte.solde);
               
            }
            Console.WriteLine("==========================================");
            Console.ReadLine();
        }
    }
}
