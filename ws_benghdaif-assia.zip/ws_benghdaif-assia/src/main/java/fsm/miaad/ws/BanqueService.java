package fsm.miaad.ws;

import java.util.Date;
import java.util.Vector;
import fsm.miaad.model.Compte;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

@WebService(serviceName = "BankWS")
public class BanqueService {

    @WebMethod(operationName = "Convert")
    public double conversion(@WebParam(name = "amount") double m){
        return m*11.23;
    }


    @WebMethod
    public Compte getCompte(@WebParam(name = "code") int code){
        return new Compte(code, Math.random()*2001, new Date());
    }


    @WebMethod
    public Vector<Compte> allComptes(){
        Vector<Compte> comptes=new Vector<>();

        comptes.add(new Compte(1, Math.random()*2001, new Date()));
        comptes.add(new Compte(2, Math.random()*2001, new Date()));
        comptes.add(new Compte(3, Math.random()*2001, new Date()));
        return comptes;

    }
    
    
}
