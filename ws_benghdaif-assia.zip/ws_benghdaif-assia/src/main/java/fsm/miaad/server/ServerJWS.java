package fsm.miaad.server;

import fsm.miaad.ws.BanqueService;
import jakarta.xml.ws.Endpoint;

public class ServerJWS {

    public static void main(String[] args) {
        
        String host="localhost",protocol="http";
        int port=2001;
        String address=protocol+"://"+host+":"+port+"/";
        BanqueService bank=new BanqueService();
        
        // lancer le service
        Endpoint.publish(address, bank);
        System.out.println("++++++++++++++++++++++++++++++++++++++++++\nservice lanced");
    }
    
}
